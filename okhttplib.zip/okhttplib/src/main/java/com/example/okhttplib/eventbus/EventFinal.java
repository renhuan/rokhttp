package com.example.okhttplib.eventbus;

public final class EventFinal {
    public static final int MAIN_A = 0x911111;
    public static final int MAIN_B = 0x981111;
    public static final int MAIN_C = 0x971111;
    public static final int A = 0x111111;
    public static final int B = 0x222222;
    public static final int C = 0x333333;
    public static final int D = 0x444444;
}
